import time

vraag = input("DON'T TYPE IN QUIT!!  ")

while vraag != "quit":
    time.sleep(1)
    print("Okay, good.")
    time.sleep(1)
    print("you didn't type in quit")
    time.sleep(1)
    print("good job buddy!")
    time.sleep
    print("I'm proud of you")
    vraag = input("DON'T TYPE IN QUIT!!  ")



print("Bruh")
time.sleep(1)
print("I told you")
exit()
