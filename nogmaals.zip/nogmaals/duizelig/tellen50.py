import time
totalsum = 0
number = 50
while totalsum < 1001:
    print(totalsum)
    number = number + 1
    totalsum = totalsum + number

    



##### IK WEET NIET OF IK DIT GOED HEB GEDAAN MAAR IK WAS HIER 2 UUR MEE BEZIG EN IK SNAP ER NOG STEEDS HELEMAAL NIKS VAN
#FUCK DEZE OPDRACHT