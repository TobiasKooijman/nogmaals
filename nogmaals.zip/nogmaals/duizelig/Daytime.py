import time
xy=0
while xy <= 11:
    xy = (xy+1)
    character = "am"
    print(xy,character)
    time.sleep(1)
p=0
while p <= 11:
    p = (p+1)
    character = "pm"
    print(p,character)
    time.sleep(1)